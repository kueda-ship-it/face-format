module.exports = {
    plugins: {}
};
